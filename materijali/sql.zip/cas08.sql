
-- count(*) ili (kolona) - ne null vrednosti ili (distinct kolona)
-- sum(kolona), min(kolona), max(kolona), avg(kolona), stddev()

-- select agr.fja
-- from
-- where - ne moze ovde jer se radi za svaki red posebno (a mi radimo sa kolonama)

-- Ne moze: select indeks, agr.fja - ne znamo koji indeks treba da izdvojimo

-- 1.
--select count(*) "Broj studenata" 
--from dosije;
--
--select count "Broj studenata" 
--from dosije;
-- 
--select count(indeks) "Broj studenata" 
--from dosije;

-- 2.
--select count(distinct indeks) "Broj studenata"
--from ispit
--where ocena = 10

-- 3. 
--select count "Broj predmeta", sum(p.bodovi) "Broj bodova"
--from ispit i join predmet p 
--		on i.id_predmeta = p.id_predmeta
--where i.indeks = 20140025 and i.ocena > 5;

-- 4. 
--select nullif(ocena, 5)
--from ispit

-- 5. 
--select count(distinct nullif(ocena, 5))
--from ispit

-- 6.
--select sifra, naziv, bodovi
--from predmet
--where bodovi > (select avg(bodovi)
--				from predmet)

-- select agr.fje - za svaku grupu posebno se izracunavaju
--				  - sada mogu da se koriste sve kolone iz group by
-- from 
-- where 
-- group by kol1, kol2,...,koln - grupisemo elemente dobijene iz from i where

-- 7.
--select count(*)
--from predmet join ispit
--	on predmet.id_predmeta = ispit.id_predmeta
--where ocena > 5
--group by predmet.id_predmeta;

-- 8.
--select d.indeks, dec(avg(ocena*1.0), 7, 2) prosek, 
--	   min(ocena) minimum, max(ocena) maximum 
--from dosije d join ispit i
--		on d.indeks = i.indeks
--where year(datum_rodjenja) = 1995 
--	and ocena > 5
--group by d.indeks

-- 9. 
--select godina_roka, p.naziv, max(ocena)
--from ispit i join predmet p
--	on i.id_predmeta = p.id_predmeta
--group by godina_roka, p.id_predmeta, p.naziv

-- having uslovi sa argegatnim funkcijama +
--		  uslovi nad izrazima iz group by
-- moze da se koristi samo u kombinaciji sa group by

-- 10.
--select naziv
--from predmet p join ispit i
--	on p.id_predmeta = i.id_predmeta
--group by p.naziv, p.id_predmeta
--having count(distinct indeks) > 5

-- 11. 
--select oznaka_roka, count(*) "Broj ispita", count(distinct indeks) "Broj studenata"
--from ispit 
--where godina_roka = 2015
--group by oznaka_roka
--having min(ocena) > 5

-- 12. 
--select p.naziv, count(distinct indeks) "Broj studenata"
--from predmet p left join ispit i
--	on p.id_predmeta = i.id_predmeta
--group by p.naziv, p.id_predmeta
--order by count(distinct indeks) desc

-- ili

-- neefikasno resenje
--select p.naziv, (select count
--				from ispit i
--				where p.id_predmeta = i.id_predmeta)
--from predmet p

-- 13.
--select indeks, monthname(datum_ispita) "Mesec", count(distinct id_predmeta) "Broj predmeta"
--from  ispit 
--where ocena > 5
--group by indeks, monthname(datum_ispita)
--having count > 2
--order by indeks, monthname(datum_ispita)

-- 14. 
-- 1. nacin
--select count
--from(
--	select indeks, sum(p.bodovi)
--	from ispit i join predmet p
--		on i.id_predmeta = p.id_predmeta
--		and ocena > 5
--	group by indeks
--	having sum(p.bodovi) > 10) as t

-- 2. nacin
--with ime(kol1, kol2, ..., koln) as(upit)
--select
--from ime

--with student_bodovi as 
--(select indeks, sum(p.bodovi) "polozeno" -- svaka kolona mora da ima ime!!!
-- from ispit i join predmet p
--		on i.id_predmeta = p.id_predmeta
--		and ocena > 5
-- group by indeks
-- having sum(p.bodovi) > 10)
--select count
--from student_bodovi

-- vise puta koristimo with:
--with ime(...) as (upit), ime2 as (upit), ime3 as (upit)
--select
--from ime