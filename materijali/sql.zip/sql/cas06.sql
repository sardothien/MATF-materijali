-- upit1 op upit2 
-- union (all), intersect (all), except (all)

-- 1. a)
--select indeks
--from dosije
--where mesto_rodjenja='Beograd'
--
--union all
--
--select indeks
--from ispit
--where ocena=10
--order by indeks desc;

-- 1. b)
--select indeks
--from dosije
--where mesto_rodjenja='Beograd'
--
--intersect all
--
--select indeks
--from ispit
--where ocena=10
--order by indeks desc;

-- 1. c)
--select indeks
--from dosije
--where mesto_rodjenja='Beograd'
--
--except all
--
--select indeks
--from ispit
--where ocena=10
--order by indeks desc;

-- 2.
-- Prvi oblik
--select indeks, id_predmeta, ocena,
--	case ocena
--	 	when 10 then 'deset'
--	 	when 9 then 'devet'
--	 	when 8 then 'osam'
--	 	when 7 then 'sedam'
--	 	when 6 then 'sest'
--	 	else 'nepolozen'  
--	 end ocena_slovima
--from ispit;

-- Drugi oblik
--select indeks, id_predmeta, ocena,
--	case 
--	 	when ocena=10 then 'deset'
--	 	when ocena=9 then 'devet'
--	 	when ocena=8 then 'osam'
--	 	when ocena=7 then 'sedam'
--	 	when ocena=6 then 'sest'
--	 	else 'nepolozen'  
--	 end ocena_slovima
--from ispit;

-- 3.
--select naziv, 
--	case
--		when bodovi>7 then 'I kategorija'
--		when bodovi between 5 and 7 then 'II kategorija'
--		else 'III kategorija'
--	end kategorija
--from predmet;

-- Drugi nacin
--select naziv, 
--	case
--		when bodovi>7 then 'I kategorija'
--		when bodovi>=5 then 'II kategorija'
--		else 'III kategorija'
--	end kategorija
--from predmet;

--values 'a', 'b', 'c'
--values ('a', 1), ('b', 2), ('c', 3)

-- 4. 
-- Prvi nacin
--select current time
--from sysibm.sysdummy1;

-- Drugi nacin
--values current time;

-- 5.
--values user;
-- ili
--select user
--from sysibm.sysdummy1;

-- 6. 
-- Prvi nacin
--select dayname(current date)
--from sysibm.sysdummy1;

-- Drugi nacin
--values dayname(date('4.11.2019'));

-- 7.
--values 
--	(dayofyear(current date),
--	week(current date),
--	dayofweek(current date),
--	dayname(current date), -- greska jer nije istog tipa kao prethodni (mora zagrade)
--	monthname(current date));
	
-- 8.
--values second(current time);

-- 9. 
--values date('11.11.2008') - date('6.8.2005');

-- 10.  
--values current date + 12 years + 5 months + 25 days;

-- 11. 
--select *
--from ispit
--where datum_ispita > date('28.1.2015');
-- moze samo i niska, bez date

-- 12. 
--select *
--from ispit
--where current_date - datum_ispita < 800;

-- 13. 
--select indeks, naziv, ocena, 
--	   year(current date - datum_ispita) godina,
--	   month(current date - datum_ispita) meseci,
--	   day(current date - datum_ispita) dani,
--	   days(current date) - days(datum_ispita) "ukupan broj dana"
--from ispit, predmet
--where ispit.id_predmeta = predmet.id_predmeta
--	and current_date - datum_ispita < 50000;
	
-- 14.
--select indeks, ime || ' ' || prezime ime_prezime, 
--	   replace(mesto_rodjenja, 'Beograd', 'Bg') mesto_rodjenja,
--	   substr(ime, 1,1) || substr(prezime,1,1) inicijali
--from dosije;

-- 15.
--select indeks, ime, prezime,
--	   coalesce(mesto_rodjenja, 'Nepoznato') mesto_rodjenja
--from dosije;

-- 16.
--values (char(current date, EUR),
--		char(current time, EUR)),
--	   (char(current date, USA),
--		char(current time, USA)),
--	   (char(current date, ISO),
--		char(current time, ISO));

--values trunc(586.25589, 1);
--values round(586.25589, 1);
--values dec(round(586.25589, 2), 6, 2);

-- 17. a)
--select predmet.*,
--	   dec(bodovi*1.2, 5, 2) nakon_uvecanja
--from predmet;

-- 17. b)
--select predmet.*,
--	   ceil(bodovi*1.2) nakon_uvecanja
--from predmet
--where ceil(bodovi*1.2) > 8;

-- KRAJ ZA KOLOKVIJUM

-- 18.
--select substr(indeks, 5) || '/' || substr(indeks, 1, 4)
--from ispit i1
--where ocena = 10
--	  and not exists (select *
--	  				  from ispit i2
--	  				  where i2.ocena = 10 
--	  				  		and i1.id_predmeta = i2.id_predmeta
--	  				  		and i1.indeks <> i2.indeks);

-- 19. 
select naziv, coalesce(dayname(datum_ispita), 'nije bilo ispita ili je nepoznat datum')
from ispit i right join ispitni_rok ir
	on i.godina_roka = ir.godina_roka 
	and i.oznaka_roka = ir.oznaka_roka
where ir.godina_roka between 2000 and 2015;