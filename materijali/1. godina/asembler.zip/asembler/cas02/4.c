#include <stdio.h>

unsigned suma_cifara(unsigned x);

int main(){
 unsigned x;
 scanf("%u", &x);
 
 printf("%u\n", suma_cifara(x));
 
 return 0;
}
