#include <stdio.h>

unsigned suma(unsigned x);

int main(){
 unsigned x;
 scanf("%u", &x);
 
 printf("%u\n", suma(x));
 
 return 0;
}
