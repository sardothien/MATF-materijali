#include <stdio.h>

unsigned prestupna(unsigned x);

int main(){
 unsigned x;
 scanf("%u", &x);
 
 printf("%u\n", prestupna(x));
 
 return 0;
}
