#include <stdio.h>

int deljiv_4(int x);

int main(){
 int x;
 scanf("%d", &x);
 
 printf("%d\n", deljiv_4(x));
 
 return 0;
}
