#include <stdio.h>

unsigned prost(unsigned);

int main(){
 unsigned n;
 scanf("%d", &n);
 
 printf("%d\n", prost(n));
 
 return 0;
}
