#include <stdio.h>

unsigned najveca_cifra(unsigned);

int main(){
 unsigned n;
 scanf("%u", &n);
 
 printf("%u\n", najveca_cifra(n));
 
 return 0;
}
