#include <stdio.h>

unsigned broj_jedinica(unsigned);

int main(){
 unsigned x;
 scanf("%u", &x);
 
 printf("%u\n", broj_jedinica(x)); 
 
 return 0;
}
