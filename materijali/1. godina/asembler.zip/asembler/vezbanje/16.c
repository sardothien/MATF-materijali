#include <stdio.h>

unsigned vrednost(unsigned);

int main(){
 unsigned n;
 scanf("%u", &n);
 
 printf("%u\n",vrednost(n)); 
 
 return 0;
}
