#include <stdio.h>

int clan_niza(int);

int main(){
 int n;
 scanf("%d", &n);
 
 printf("%d\n", clan_niza(n)); 
 
 return 0;
}
