#include <stdio.h>

unsigned faktorijel(unsigned);

int main(){
 unsigned n;
 scanf("%u", &n);
 
 printf("%u\n", faktorijel(n));
 
 return 0;
}
