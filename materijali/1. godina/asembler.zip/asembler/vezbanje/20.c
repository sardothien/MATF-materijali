#include <stdio.h>

unsigned suma_cifara(unsigned);

int main(){
 unsigned x;
 scanf("%u", &x);
 
 printf("%u\n", suma_cifara(x)); 
 
 return 0;
}
