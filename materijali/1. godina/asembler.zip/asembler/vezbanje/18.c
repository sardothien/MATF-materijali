#include <stdio.h>

int hipotenuza(int, int);

int main(){
 int x, y;
 scanf("%d%d", &x, &y);
 
 printf("%d\n", hipotenuza(x, y)); 
 
 return 0;
}
