#include <stdio.h>

int maksimum(int a, int b);

int main(){
 int a, b;
 scanf("%d%d", &a, &b);
 
 printf("%d\n", maksimum(a, b));
 
 return 0;
}
