#include <stdio.h>

int bitska_negacija(int x);

int main(){
 int x;
 scanf("%d", &x);
 
 printf("%d\n", bitska_negacija(x));
 
 return 0;
}
