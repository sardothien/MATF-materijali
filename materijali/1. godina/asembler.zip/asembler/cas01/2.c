#include <stdio.h>

int sabiranje(int x, int y);

int main(){
 int x, y;
 scanf("%d%d", &x, &y);
 
 printf("%d\n", sabiranje(x,y));
 
 return 0;
}
