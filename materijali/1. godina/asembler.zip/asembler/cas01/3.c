#include <stdio.h>

int oduzimanje(int x, int y);

int main(){
 int x, y;
 scanf("%d%d", &x, &y);
 
 printf("%d\n", oduzimanje(x,y));
 
 return 0;
}
