/* Napisati program koji 5 puta ispisuje tekst Mi volimo da programiramo. */

#include <stdio.h>

int main(){
 
 int i;
 i=0;
 while(i<5){
  printf("Mi volimo da programiramo.\n");
  i++;
 }

 return 0;
}
