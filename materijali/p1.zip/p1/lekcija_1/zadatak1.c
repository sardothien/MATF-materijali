/* Napisati program koji na standardni izlaz ispisuje tekst Zdravo, svete! */

#include <stdio.h>
int main(){
  printf("Zdravo, svete!\n");
  return 0;
}
