% Neka je funkcija f zadata eksplicitno komadnim M-fajlom funkcija:m.
f=@(x) (x+1).^3.*exp(x/100);