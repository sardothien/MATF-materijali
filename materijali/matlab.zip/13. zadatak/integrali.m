% Formirati M-fajl integral.m sa funkcijom integral(f, a, b)
% koja racuna i vraca vrednost integral^b_a(f(x)dx).
% Dozvoljeno je koriscenje ugradjene MATLAB funkcije za 
% izracunavanje integrala.
function I = integrali(f, a, b)

I = integral(f, a, b);