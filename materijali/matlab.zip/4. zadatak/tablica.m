% Neka je funkcija f zadata tablicno M-fajlom tablica.m 
% koji generise dva niza X i Y za tu tablicno zadatu funkciju.
% Tablica ne mora biti ekvidistantna.
X = [100,121,144];
Y = [10,11,12];