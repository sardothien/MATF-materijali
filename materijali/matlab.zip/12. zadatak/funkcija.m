% Neka je funkcija f (koja ne mora biti (samo) pozitivna) zadata 
% eksplicitno funkcijskim M-fajlom funkcija.m.
f = @(x) x.^5;