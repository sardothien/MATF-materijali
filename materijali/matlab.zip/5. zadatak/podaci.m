% Neka su u komandnom fajlu podaci.m dati funkcija f 
% i vektor X koji sadrzi samo celobrojne vrednosti.
X=[1,2,3,5,6,7,8,10];
f=@(x) sqrt(x);