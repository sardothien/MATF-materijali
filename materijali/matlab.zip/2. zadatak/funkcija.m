% Neka je funkcija f zadata eksplicitno komandnim
% M-fajlom funkcija.m
f=@(x) 1./(1+x.^2);