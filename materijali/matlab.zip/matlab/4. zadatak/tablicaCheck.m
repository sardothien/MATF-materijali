function t=tablicaCheck()

tablica;

HX = diff(X);
tx = all(HX>0);

HY = diff(Y);
ty = all(HY>=0) || all(HY<=0);

t = tx && ty;