X=1:5;
Y=sin(X);