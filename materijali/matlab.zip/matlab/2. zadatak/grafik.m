function grafik(a,b,n)

[L,y]=Lagr1b(1,a,b,n);

funkcija;

X=linspace(a,b);
Y=f(X);

hold on
plot(X,Y,'b');
plot(X,polyval(L,X), 'k');
hold off