function [X,Y]=tablica(a,b,n)
funkcija;
X=linspace(a,b,n);

Y=f(X);