function [L,y] = Lagr1b(x,a,b,n)

L = 0;
[X,Y] = tablica(a,b,n);
n = length(X);

for i=1:n
    proizvod = 1;
    for j=1:n
        if i ~= j
            proizvod = conv(proizvod, [1, -X(j)]/(X(i)-X(j)));
        end
    end
    L = L + proizvod*Y(i);
end

y=polyval(L, x);