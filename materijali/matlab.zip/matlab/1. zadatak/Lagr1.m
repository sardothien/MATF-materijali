function L = Lagr1(x)

novatablica;

n = length(X1);
L = 0;

for i=1:n
    proizvod = 1;
    for j=1:n
        if i ~= j
            proizvod = proizvod * (x-X1(j))/(X1(i)-X1(j));
        end
    end
    L = L + proizvod*F1(i);
end