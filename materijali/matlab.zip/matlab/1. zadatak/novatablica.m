tablica;

n = length(X);
X1 = zeros(1, 2*n-1);
F1 = zeros(1, 2*n-1);

for i=1:n
    X1(2*i-1) = X(i);
    F1(2*i-1) = F(i);    
end

for i=2:2:2*n-1
    X1(i) = (X1(i-1) + X1(i+1))/2; 
    F1(i) = (F1(i-1) + F1(i+1))/2;
end