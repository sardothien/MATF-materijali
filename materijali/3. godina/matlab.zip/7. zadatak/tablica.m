% Neka je funkcija f zadata tablicno M-fajlom tablica.m
% koji generise dva niza X = [x1,...,xn] i Y = [y1,...,yn]
% (od kojih je prvi strogo rastuci) za tu tablicno zadatu
% funkciju. Tablica ne mora biti ekvidistantna.
X=[-2 -1.5 0 0.7 0.9 1.1];
Y=2.*X-exp(X);