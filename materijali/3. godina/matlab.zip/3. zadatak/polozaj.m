% Napisati M-fajl polozaj.m sa funkcijom polozaj(x) 
% koja za uneti argument x vraca vrednost 1 ukoliko 
% je x < x2, 2 ukoliko je x > x_n-1 i 0 inace.
function p = polozaj(x)

tablica;

if x < X(2)
    p = 1;
elseif x > X(end-1)
   p = 2; 
else
   p = 0;
end