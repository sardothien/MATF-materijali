% Neka je funkcija f zadata tablicno M-fajlom
% tablica.m koji generise dva niza X i F za tu tablicno 
% zadatu funkciju.
X = -3:3;
f = @(x) x.^6;
F = f(X);