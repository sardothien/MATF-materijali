% Napisati M-fajl tablica.m sa funkcijom [X, Y]=tablica(a,b,n)
% koja tabelira funkciju f na intervalu [a, b] sa n
% ekvidistantnih cvorova.
function [X, Y] = tablica(a, b, n)

funkcija;
X = linspace(a, b, n);
Y = f(X);