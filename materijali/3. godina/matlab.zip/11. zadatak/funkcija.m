% Neka je funkcija f zadata eksplicitno komadnim M-fajlom funkcija.m.
f = @(x) exp(x.^2);