% Napisati M-fajl tablica.m sa funkcijom [X, Y] = tablica(a, b, n)
% koja formira ekvidistantnu tabelu funkcije f na segmentu [a, b]
% sa n cvorova.
function [X,Y] = tablica(a, b, n)

funkcija;

X = linspace(a, b, n);
Y = f(X);