% Neka je funkcija f zadata tablicno M-fajlom tablica.m 
% koji generise dva niza X i F (od kojih je prvi strogo
% rastuci) za tu tablicno zadatu funkciju. Tablica ne mora 
% biti ekvidistantna.

X=[100,121,144];
F=[10,11,12];