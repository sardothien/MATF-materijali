#ifndef _TOKENI_H
#define _TOKENI_H

#define DISP 1
#define OZ 2
#define ZZ 3
#define UO 4
#define UZ 5
#define ID 6
#define DOD 7
#define ZAR 8
#define BROJ 9
#define EOI 0

#endif
