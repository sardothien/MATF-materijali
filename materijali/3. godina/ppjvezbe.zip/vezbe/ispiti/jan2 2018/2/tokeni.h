#ifndef _TOKENI_H
#define _TOKENI_H

#define KONJ 1
#define DISJ 2
#define NEG 3
#define DOD 4
#define TRUE 5
#define FALSE 6
#define UNDEF 7
#define ID 8
#define EOI 0

#define E 9
#define EP 10
#define T 11
#define TP 12
#define F 13

#endif
