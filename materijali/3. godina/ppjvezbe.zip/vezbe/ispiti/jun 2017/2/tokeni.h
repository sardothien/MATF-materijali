#ifndef _TOKENI_H
#define _TOKENI_H

#define PRINT 1
#define TZ 2
#define TACKA 3
#define OZ 4
#define ZZ 5
#define ZAR 6
#define BROJ 7
#define EOI 0

#endif
