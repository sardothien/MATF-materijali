#ifndef _TOKENI_H
#define _TOKENI_H

#define PRINT 1
#define DOD 2
#define BROJ 3
#define ID 4
#define TZ 5
#define ZAR 6
#define OZ 7
#define ZZ 8
#define UO 9
#define UZ 10
#define PLUS 11
#define MINUS 12
#define PUTA 13
#define EOI 0

#endif
