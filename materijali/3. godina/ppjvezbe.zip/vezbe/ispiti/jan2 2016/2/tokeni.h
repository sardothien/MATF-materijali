#ifndef _TOKENI_H
#define _TOKENI_H

#define KONJ 1
#define DISJ 2
#define TRUE_ID 3
#define FALSE_ID 4
#define NEG 5
#define ID 6
#define OZ 7
#define ZZ 8
#define EOI 0

#endif
