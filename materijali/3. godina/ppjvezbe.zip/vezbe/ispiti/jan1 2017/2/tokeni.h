#ifndef _TOKENI_H
#define _TOKENI_H

#define ID 1
#define DATE 2
#define TZ 3
#define ZAR 4
#define DOD 5
#define BROJ 6
#define APOS 7
#define TACKA 8
#define CRTA 9
#define KOSA 10
#define EOI 0

#endif
