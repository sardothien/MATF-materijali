#ifndef _TOKENI_H
#define _TOKENI_H

#define INT 1
#define DOD 2 
#define ID 3
#define TZ 4 
#define OZ 5
#define ZZ 6
#define PRINT 7
#define ILI 8
#define III 9
#define NEG 10 
#define BROJ 11
#define EOI 0

#endif
