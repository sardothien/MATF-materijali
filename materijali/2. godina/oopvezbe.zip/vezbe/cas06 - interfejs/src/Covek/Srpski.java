package Covek;

public interface Srpski {
    void zdravo();
    void dovidjenja();
    void hvala();
}
