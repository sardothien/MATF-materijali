package Covek;

public interface Engleski {
    void hello();
    void goodbye();
    void thanks();
}
