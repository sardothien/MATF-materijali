package Geometrija;

public interface Povrsina {
    double getPovrsina();
}
