package Stek;

public interface Stek {
    public int pop();
    public void push(int x);
    public int top();
    public void show();
    public int size();
}
