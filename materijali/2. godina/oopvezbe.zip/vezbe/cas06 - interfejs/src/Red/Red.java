package Red;

public interface Red {
    void add(int x);
    int remove();
    int head();
    int back();
    int size();
    void show();
}
