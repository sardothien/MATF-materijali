package Izraz;

public abstract class Izraz {
    public abstract double izracunaj();
}
