package IzrazKloniranje;

public abstract class Izraz {
    public abstract double izracunaj();
    public abstract Izraz klon();
}
