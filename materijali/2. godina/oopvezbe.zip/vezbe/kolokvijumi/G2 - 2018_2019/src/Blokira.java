public interface Blokira {
    boolean isBlokira();
    void setBlokira(boolean blok);
}
