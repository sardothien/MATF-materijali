public interface BivaBacen {
    void baci();
}
