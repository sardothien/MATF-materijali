package Polinomial;

public class Main {
}
