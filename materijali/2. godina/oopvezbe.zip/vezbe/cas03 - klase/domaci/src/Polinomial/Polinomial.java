package Polinomial;

public class Polinomial {
}
