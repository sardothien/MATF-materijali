package Program;

public class Main {

    public static void main(String[] args) {
        Program p1 = new Program("10101011111011101101010110101101010110101010101101001010101", "vim", 3, 7, 2.8);
        System.out.println(p1);

        /* TODO: implementirati zamenu tj. u masinskom kodu programa treba umetnuti
            sekvencu 001001001 odmah posle svake sekvence 111.
         */
    }
}
