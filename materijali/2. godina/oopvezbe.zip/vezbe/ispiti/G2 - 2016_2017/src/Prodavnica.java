import java.util.List;

public class Prodavnica {

    private List<VideoIgra> videoIgre;

    public Prodavnica(List<VideoIgra> videoIgre) {
        this.videoIgre = videoIgre;
    }

    public List<VideoIgra> getVideoIgre() {
        return videoIgre;
    }


}
