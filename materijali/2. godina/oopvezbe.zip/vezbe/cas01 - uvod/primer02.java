public class primer02 {
    public static void main(String[] args) {
        int x = 10, y = 20;
        int z = x + y;

        System.out.println(z);
        System.out.println(x+y);
        System.out.println("Zbir: " + (x+y));

        String str = "Zdravo";
        str += " ";
        str += "svete" + "!";
        System.out.println(str);
    }
}
