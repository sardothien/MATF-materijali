package GenerickiStek;

public class PotkoracenjeSteka extends RuntimeException {
}
