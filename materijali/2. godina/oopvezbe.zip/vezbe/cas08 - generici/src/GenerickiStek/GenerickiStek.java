package GenerickiStek;

public interface GenerickiStek<T> {

    T top();
    T pop();
    void push(T vr);
}
